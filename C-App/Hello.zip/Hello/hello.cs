using Drukuj = System.Console;
public class Hello {
	public static void Main(string[] args) {
		Drukuj.WriteLine("Hello World");
		Drukuj.Read();
	}
}